package com.blueplanet.lab.routing.neo4j.rules.constants;

public class ProjectKeys {
    public static final String deviceName = "deviceName";
    public static final String SerchKey ="BACKUP";

}