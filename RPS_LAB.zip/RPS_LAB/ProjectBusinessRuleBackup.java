package com.blueplanet.lab.routing.neo4j.rules.exam;
import org.neo4j.graphdb.Node;
import com.blueplanet.lab.routing.neo4j.rules.constants.ProjectKeys;
import com.blueplanet.lab.routing.neo4j.rules.debug.Debug;
import com.blueplanet.routing.neo4j.constants.Labels;
import com.blueplanet.routing.neo4j.core.AnalysisInformationEnriched;
import com.blueplanet.routing.neo4j.core.BusinessRule;
import com.blueplanet.routing.neo4j.core.PathConnection;
import com.blueplanet.routing.neo4j.io.RoutingException;
import com.blueplanet.routing.neo4j.core.AnalysisInformationEnriched;
import com.blueplanet.routing.neo4j.io.RoutingException;


public class ProjectBusinessRuleBackup extends BusinessRule {
    @Override
    public boolean isSatisfied(AnalysisInformationEnriched analysisInfo) throws RoutingException {
        Node endNode=analysisInfo.end();
        
        if(endNode.hasLabel(Labels.PhysicalConnection)){
            Debug debug = new Debug(this, analysisInfo);
            debug.show(true);
            PathConnection pathconection= analysisInfo.getConnection();
            String conectionName=pathconection.getGraphName();
            if(conectionName.toUpperCase().contains(ProjectKeys.SerchKey)){
              return true;
            }


        }
        return false;
      }
    
} 